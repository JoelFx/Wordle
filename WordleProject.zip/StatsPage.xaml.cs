namespace WordleSolution;

public partial class StatsPage : ContentPage
{
    public WordRow[] Rows { get; }
    public StatsPage()
    {
        InitializeComponent();
        Rows = new WordRow[6]
            {
            new WordRow(),
            new WordRow(),
            new WordRow(),
            new WordRow(),
            new WordRow(),
            new WordRow()
            };
    }
}