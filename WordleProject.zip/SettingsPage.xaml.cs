namespace WordleSolution;

public partial class SettingsPage : ContentPage
{
    Settings set;
    private int sizer;
    public SettingsPage(Settings s)
    {
        this.set = s;
        InitializeComponent();
        sizer = Preferences.Default.Get("sizer", 18);
        sizerChange.Value = sizer;
        
        UpdateSizerNumber();
        BindingContext = set;
    }

    private void CurrentTime(object sender, EventArgs e)
    {
        MainThread.BeginInvokeOnMainThread(() =>
        {
            var timer= new System.Threading.Timer(obj =>
            {
                MainThread.InvokeOnMainThreadAsync(() => { TimeNow.Text = "Time: " + DateTime.UtcNow.ToString("t"); });
            }, null,TimeSpan.FromSeconds(1), TimeSpan.FromSeconds(1));
        });
    }

    private void btnTime_Clicked(object sender, EventArgs args)
    {
        this.Loaded += CurrentTime;
    }
    private void LightDark_Switched(object sender, ToggledEventArgs args)
    {
        Switch xyz = sender as Switch;
        Application.Current.UserAppTheme = xyz.IsToggled ? AppTheme.Dark : AppTheme.Light;
    }

    private void Hint_ButtonClicked(object sender, EventArgs args) //After 3 guesses
    {
        lblHint.Text = "Hint: Use the vowel letters for those are need or not need for a word.\nExample, the vowel letters are A, E, I, O, U for part of the word.".ToString();
    }

    private new void SizeChanged(object sender, ValueChangedEventArgs args)
    {
        sizer = (int)sizerChange.Value;
        UpdateSizerNumber();
    }
    private void UpdateSizerNumber()
    {
        lblSizerValue.Text = sizerChange.Value.ToString() + " font sizer selected ";
    }
    private async void CloseButton_Clicked(object sender, EventArgs e)
    {
        set.SaveJson();
        await Navigation.PopAsync();
    }
}