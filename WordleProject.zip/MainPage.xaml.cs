﻿using System.ComponentModel;
using System.Text.Json;
using System.Windows.Input;

namespace WordleSolution
{
    public partial class MainPage : ContentPage
    {
        // 0 - 5 
        int rowIndex;
        // 0 - 4
        int columnIndex;

        private WordRow[] rows;
        public WordRow[] Rows { get => rows; set { rows = value; } }
        private Settings set;
        private bool fromsettingspage = false;
        private int winnerOfGame = -1;
        public int GamesWon { get; set; }
        public int GamesWonP1 { get; set; }
        public int GamesWonP2 { get; set; }
        public int GamesPlayed { get; set; }
        public int GamesPlayedP1 { get; set; }
        public int GamesPlayedP2 { get; set; }
        private bool guessingwordle = false;
        private bool loadingpage = false;
        private List<Player> players;
        private int playerTurn;
        private bool submitword = false; 
        private bool everythingInitialised = false;
        private int choice = 0;
        char[] currentWordToGuess;
        private int ChangeSize;
        private int numberOfPlayers;

        public ICommand AddCharCommand { protected set; get; } //Adding Input Letters
        public ICommand DeleteCharCommand { protected set; get; } //Deleting Input Letters
        public ICommand EnterCommand { protected set; get; } //Entering a five-letter word

        public bool LoadingPage
        {
            get => loadingpage;
            set
            {
                loadingpage = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(EverythingLoaded));
            }
        }

        public bool EverythingLoaded => !LoadingPage;


        private bool GuessingWordle
        {
            get => guessingwordle;
            set
            {
                if (guessingwordle != value)
                {
                    guessingwordle = value;
                    OnPropertyChanged(nameof(TopText));
                }
            }
        }
        private int WinnerGame
        {
            get => winnerOfGame;
            set
            {
                if (winnerOfGame != value)
                {
                    winnerOfGame = value;
                    OnPropertyChanged(nameof(TopText));
                }
            }
        }
        private bool SubmitWord
        {
            get => submitword;
            set
            {
                if (submitword != value)
                {
                    submitword = value;
                    OnPropertyChanged(nameof(TopText));
                }
            }
        }
        public string TopText
        {
            get
            {
                if (players == null || players.Count == 0)
                    return "";
                if (WinnerGame != -1)
                    return "Well done " + players[playerTurn].name + " you have won!!\nIf you'd like to start again, \nclick the New Game Button";
                else if (GuessingWordle)
                    return "Please Wait, Guessing Wordle!";
                else if (SubmitWord)
                    return "Submitting the correct word, \nlet's see what you get";
                else
                    return players[playerTurn].name + ", it's your go - \nGuess the correct word";
            }
        }
        public int NumberGuesses { get; set; } = 0;
        public int NumberGuessesP1 { get; set; } = 0;
        public int NumberGuessesP2 { get; set; } = 0;


        public MainPage()
        {
            InitializeComponent();
            this.LayoutChanged += OnWindowChange;
            var frame = new Frame();
            AddCharCommand = new Command(async () => await EnterLetter('A'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('B'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('C'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('D'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('E'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('F'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('G'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('H'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('I'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('J'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('K'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('L'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('M'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('N'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('O'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('P'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('Q'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('R'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('S'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('T'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('U'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('V'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('W'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('X'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('Y'));
            OnPropertyChanged();
            AddCharCommand = new Command(async () => await EnterLetter('Z'));
            OnPropertyChanged();

            DeleteCharCommand = new Command(async () => await EnterLetter('⌫'));
            OnPropertyChanged();

            EnterCommand = new Command(async () => await EnterLetter('↵'));
            OnPropertyChanged();

            GamesWon = Preferences.Default.Get("wonGames", 0);
            GamesPlayed = Preferences.Default.Get("playedGames", 0);
            GamesWonP1 = Preferences.Default.Get("wonGamesP1", 0);
            GamesPlayedP1 = Preferences.Default.Get("playedGamesP1", 0);
            GamesWonP2 = Preferences.Default.Get("wonGamesP2", 0);
            GamesPlayedP2 = Preferences.Default.Get("playedGamesP2", 0);

            InitializeGame();
        }


        private void InitializeGame()
        {

            Rows = new WordRow[6]
            {
                new WordRow(),
                new WordRow(),
                new WordRow(),
                new WordRow(),
                new WordRow(),
                new WordRow()
            };
            LoadRandomWord();
        }

        private void InitialisePlayers(int howmany)
        {
            players = new List<Player>();
            playerTurn = 0;
            string[] defaults = { "Player 1", "Player 2" };
            for(int i=0; i < howmany; i++)
            {
                players.Add(new Player(Preferences.Default.Get("Player " + i, defaults[i]), i + 1));
            }
            numberOfPlayers = howmany;
        }

        private async Task LoadRandomWordFromList()
        {
            //read in the words.txt and add the current word to guess to a variable for comparison
            var localFolder = FileSystem.AppDataDirectory;
            var localFilePath = Path.Combine(localFolder, "words.txt");

            if (File.Exists(localFilePath))
            {
                var allWords = await File.ReadAllLinesAsync(localFilePath);
                if (allWords.Length > 0)
                {
                    var random = new Random();
                    currentWordToGuess = allWords[random.Next(allWords.Length)].ToCharArray();
                }
            }
        }

        private async void LoadRandomWord()
        {
            await LoadRandomWordFromList();
        }
        private void InitialiseObjectVariables()
        {
            string settingsfilename = System.IO.Path.Combine(FileSystem.Current.AppDataDirectory, "settings.json");
            if (File.Exists(settingsfilename))
            {
                try
                {
                    using (StreamReader reader = new StreamReader(settingsfilename))
                    {
                        string jsonstring = reader.ReadToEnd();
                        set = JsonSerializer.Deserialize<Settings>(jsonstring);
                    }
                }
                catch
                {
                    set = new Settings();
                }
            }
            else
                set = new Settings();
            UpdateSettings();
            everythingInitialised = true;
        }
        private void UpdateSettings()
        {
            ChangeSize = set.FontSizer;
        }

        private async void Settings_Clicked(object sender, EventArgs e) //Click the Settings button to go on Settings page
        {
            SettingsPage setpage = new SettingsPage(set);
            fromsettingspage = true;
            await Navigation.PushAsync(setpage);
        }
        private void OnWindowChange(object sender, EventArgs e)
        {
            if (this.Width <= 0)
                return;
            if (this.Width < 480)
            {
                int newdim = (int)this.Width / 10;
                double rescale = (double)newdim * 10 / 480;
                GridGameTable.Scale = rescale;
                TopTextLbl.WidthRequest = newdim * 10;
                //windowScale = rescale;
            }
        }
        public void Enter()
        {
            if (columnIndex != 5)
            {
                App.Current.MainPage.DisplayAlert("Invalid!", "Must input five letters in one word!", "OK");
                return;
            }

            var correct = Rows[rowIndex].Validate(currentWordToGuess);

            if (correct)
            {
                if (choice == 0)
                {
                    IncrementGamesWon(0);
                    IncrementGamesPlayed(0);
                    NumberofGuesses(rowIndex + 1, 0);
                }
                else if (choice == 1)
                {
                    IncrementGamesWon(1);
                    IncrementGamesPlayed(1);
                    NumberofGuesses(rowIndex + 1, 1);
                }
                else
                {
                    IncrementGamesWon(2);
                    IncrementGamesPlayed(2);
                    NumberofGuesses(rowIndex + 1, 2);
                }
                App.Current.MainPage.DisplayAlert("You Win!", "You are so smart!\n"+ currentWordToGuess + "is the correct answer", "OK");//Correct Answer
                App.Current.MainPage.DisplayAlert("How many guesses", "You got\n" + (rowIndex + 1) + "guesses", "OK"); //no. of guesses
                RestartGame();
                return;
            }

            if (rowIndex == 5)
            {
                App.Current.MainPage.DisplayAlert("Game Over!", "You are out of guesses", "OK"); // Out of turns
                App.Current.MainPage.DisplayAlert("Correct Answer!", "The correct answer is "+ currentWordToGuess, "OK");
                RestartGame();
            }
            else
            {
                // Incorrect Word
                rowIndex++;
                columnIndex = 0;
            }
            if (columnIndex == 5) //All 5 input letters in one word
                return;
        }

        Task EnterLetter(char letter)
        {
            if (letter == '↵') //Clicked ↵ button
            {
                Enter();
                return Task.CompletedTask;
            }

            if (letter == '⌫') //Clicked ⌫ button
            {
                if (columnIndex == 0)
                    return Task.CompletedTask;
                columnIndex--;
                Rows[rowIndex].Letters[columnIndex].Input = ' ';
                return Task.CompletedTask;
            }

            if (columnIndex == 5) //Clicked alphabetical letter buttons only
            {
                return Task.CompletedTask;
            }

            Rows[rowIndex].Letters[columnIndex].Input = letter;
            columnIndex++;
            return Task.CompletedTask;
        }

        private void RestartGame()
        {
            foreach (var item in GridGameTable.Children)
            {
                if (item is WordRow)
                {
                    Label inputL = (Label)item;
                    inputL.Text = " ";
                    Frame inputF = (Frame)item;
                    inputF.BackgroundColor = Color.FromRgb(255, 255, 255);
                }
            }
        }

        /*private void ResetPlayersForNewGame()
        {
            foreach(var player in players)
            {
                players.Clear();
                InitialisePlayers(Preferences.Default.Get("numberplayers", 2));
                WinnerGame = -1;
            }
        }*/
        public void IncrementGamesWon(int choice)
        {
            if (choice == 0)
            {
                Preferences.Default.Set("wonGames", ++GamesWon);
            }
            else if (choice == 1) {
                Preferences.Default.Set("wonGamesP1", ++GamesWonP1);
            }
            else {
                Preferences.Default.Set("wonGamesP1", ++GamesWonP1);
                Preferences.Default.Set("wonGamesP2", ++GamesWonP2);
            }
        }

        public void IncrementGamesPlayed(int choice)
        {
            if (choice == 0)
            {
                Preferences.Default.Set("playedGames", ++GamesPlayed);
            }
            else if (choice == 1)
            {
                Preferences.Default.Set("playedGamesP1", ++GamesPlayedP1);
            }
            else
            {
                Preferences.Default.Set("playedGamesP1", ++GamesPlayedP1);
                Preferences.Default.Set("playedGamesP2", ++GamesPlayedP2);
            }
        }

        public void NumberofGuesses(int attempt, int choice)
        {
            if (choice == 0)
            {
                NumberGuesses += attempt;
                Preferences.Default.Set("NumberGuesses", NumberGuesses);
            }
            else if (choice == 1)
            {
                NumberGuessesP1 += attempt;
                Preferences.Default.Set("NumberGuessesP1", NumberGuessesP1);
            }
            else
            {
                NumberGuessesP1 += attempt;
                Preferences.Default.Set("NumberGuessesP1", NumberGuessesP1);
                NumberGuessesP2 += attempt;
                Preferences.Default.Set("NumberGuessesP2", NumberGuessesP2);
            }
        }
        private async void btnHelp_Clicked(object sender, EventArgs e) // Clicked Help Button to go on Help Page
        {
            await Navigation.PushAsync(new HelpPage());
        }

        private async void btnStats_Clicked(object sender, EventArgs e) // Clicked Statistic Button to go on Statistic Page
        {
            await Navigation.PushAsync(new StatsPage());
        }
        private async void NewGameButton_Clicked(object sender, EventArgs e) // Clicked New Game Button to start a new game
        {
            bool answer = await DisplayAlert("Are you sure", "Are you sure you want to start a new game?", "Yes", "No");
            if (!answer)
                return;
            //RestartGame();
            await Shell.Current.GoToAsync("//WelcomePage", true);
        }

        protected override void OnNavigatedTo(NavigatedToEventArgs args)
        {
            if(everythingInitialised && !fromsettingspage) {
                //ResetPlayersForNewGame();
            }
            else if (fromsettingspage)
            {
                UpdateSettings();
                fromsettingspage = false;
            }
            base.OnNavigatedTo(args);
        }
        protected override async void OnAppearing()
        {
            base.OnAppearing();
            if (!everythingInitialised)
            {
                LoadingPage = true;
                BindingContext = this;

                // This Task Delay allows the page to display before initialising all the object variables
                // This allows us to have an activity indicator while waiting for it to load
                await Task.Delay(500);
                InitialiseObjectVariables();
                LoadingPage = false;
                InitialisePlayers(Preferences.Default.Get("numberplayers", 2));
                // Do this to update the text display at the top
                WinnerGame = 0;
                WinnerGame = -1;
            }
        }
    }
}
