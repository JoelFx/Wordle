﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace WordleSolution
{
    public class Settings
    {
        private bool darklight;
        private int fontsizer;
        private bool hint;

        public int FontSizer
        {
            get => fontsizer;
            set
            {
                if (fontsizer != value)
                {
                    fontsizer = value;
                    OnPropertyChanged();
                }
            }
        }

        public bool Hint
        {
            get => hint;
            set
            {
                if (hint != value)
                {
                    hint = value;
                    OnPropertyChanged();
                }
            }
        }

        public bool DarkLight
        {
            get => darklight;
            set
            {
                if (value == darklight)
                {
                    return;
                }
                darklight = value;
                OnPropertyChanged();
            }
        }

        public Settings()
        {
            DarkLight = false;
            FontSizer = 24;
            Hint = false;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public void SaveJson()
        {
            string jsonstring = JsonSerializer.Serialize(this);
            string filename = System.IO.Path.Combine(FileSystem.Current.AppDataDirectory, "settings.json");
            using (StreamWriter writer = new StreamWriter(filename))
            {
                writer.Write(jsonstring);
            }
        }
    }
}
